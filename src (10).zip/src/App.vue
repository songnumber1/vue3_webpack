
<template>
<div class="layout">
  <aside class="sidebar" :class="[ {collapsed: !isMobile && collapsed}, {open: isMobile && mobileOpen} ]">
    <strong class="text">DS Assistant</strong>
    <div class="nav">
      <router-link to="/chat">💬 <span class="text">Chat</span></router-link>
      <router-link to="/playground">🧪 <span class="text">Playground</span></router-link>
    </div>

    <div v-if="isChatRoute">
      <div class="label">채팅</div>
      <button class="chat-new" @click="startNewChat">➕ <span class="text">새 대화</span></button>

      <div class="label">이력</div>
      <div class="chat-list">
        <button
          v-for="c in chats"
          :key="c.id"
          class="chat-item"
          :class="{active: c.id === activeChatId}"
          @click="selectChat(c.id)"
        >
          📄 <span class="text title">{{c.title}}</span>
        </button>
      </div>
    </div>

    <div style="margin-top:auto; font-size:12px; color:var(--muted)">
      <span class="text">v11</span>
    </div>
  </aside>

  <div v-if="isMobile && mobileOpen" class="overlay" @click="mobileOpen=false"></div>

  <div class="main">
    <header class="header">
      <button @click="toggleSidebar">☰</button>
      <strong>DS Assistant</strong>
      <div>
        <button class="theme-btn" :class="{active:theme==='light'}" @click="setTheme('light')">Light</button>
        <button class="theme-btn" :class="{active:theme==='dim'}" @click="setTheme('dim')">Dim</button>
        <button class="theme-btn" :class="{active:theme==='dark'}" @click="setTheme('dark')">Dark</button>
      </div>
    </header>

    <router-view
      :store="store"
      @store:update="onStoreUpdate"
      @mobile:close="mobileOpen=false"
    />
  </div>
</div>
</template>

<script>
import { loadStore, saveStore } from './services/chatStore';

export default{
  data(){
    return {
      theme: 'light',
      collapsed: false,
      mobileOpen: false,
      isMobile: window.innerWidth <= 768,
      store: loadStore()
    }
  },
  computed:{
    chats(){ return this.store.chats || [] },
    activeChatId(){ return this.store.activeChatId },
    isChatRoute(){ return this.$route.path.startsWith('/chat') }
  },
  watch:{
    '$route.path'(){
      if(this.isMobile) this.mobileOpen=false
    }
  },
  mounted(){
    const t = localStorage.getItem('theme') || 'light';
    this.setTheme(t);
    window.addEventListener('resize', this.onResize);
  },
  beforeUnmount(){
    window.removeEventListener('resize', this.onResize);
  },
  methods:{
    onResize(){
      this.isMobile = window.innerWidth <= 768;
      if(this.isMobile) this.collapsed=false;
    },
    toggleSidebar(){
      if(this.isMobile) this.mobileOpen = !this.mobileOpen;
      else this.collapsed = !this.collapsed;
    },
    setTheme(t){
      this.theme = t;
      document.documentElement.setAttribute('data-theme', t);
      localStorage.setItem('theme', t);
    },
    persist(){
      saveStore(this.store);
    },
    onStoreUpdate(newStore){
      this.store = newStore;
      this.persist();
    },
    startNewChat(){
      // "첫 메시지 전송 시 이력 생성"을 위해 draft 모드로 전환
      this.store.activeChatId = null;
      this.store.draft = true;
      this.persist();
      if(this.isMobile) this.mobileOpen=false;
      // chat view에게도 반영되도록 이벤트만 쏴도 되지만, 현재는 store 공유라 즉시 반영됨
    },
    selectChat(id){
      this.store.activeChatId = id;
      this.store.draft = false;
      this.persist();
      if(this.isMobile) this.mobileOpen=false;
    }
  }
}
</script>
