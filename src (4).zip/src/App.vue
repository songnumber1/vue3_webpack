<template>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar"
           :class="{ mobile: isMobile, open: sidebarOpen }">
      <div class="brand">
        <div class="brand-left">
          <div class="logo">◎</div>
          <div style="min-width:0">
            <div class="brand-title">DS Assistant</div>
            <div class="brand-sub">ChatGPT layout · Option API</div>
          </div>
        </div>
        <button v-if="isMobile" class="btn btn-ghost btn-sm" @click="closeSidebar">닫기</button>
      </div>

      <div class="nav">
        <button class="active" v-if="view==='chat'"><span>💬</span> Chat</button>
        <button v-else @click="go('chat')"><span>💬</span> Chat</button>

        <button class="active" v-if="view==='playground'"><span>🧪</span> Playground</button>
        <button v-else @click="go('playground')"><span>🧪</span> Playground</button>

        <div class="hr"></div>

        <div>
          <p class="room-title">임시 채팅방</p>
          <div class="room-list">
            <button v-for="c in chats"
                    :key="c.id"
                    :class="{ active: c.id === activeChatId }"
                    @click="selectChat(c.id)">
              <span>🗂️</span> {{ c.title }}
            </button>
          </div>
        </div>

        <div class="hr"></div>

        <button @click="newRoom"><span>➕</span> 새 채팅방</button>
      </div>

      <div class="sidebar-bottom">
        <div class="profile">
          <div class="avatar">MW</div>
          <div class="profile-meta">
            <div class="who">민우 송</div>
            <div class="small">sm: 햄버거 · 자동 스크롤</div>
          </div>
        </div>
      </div>
    </aside>

    <!-- Backdrop (mobile) -->
    <div v-if="isMobile && sidebarOpen" class="backdrop" @click="closeSidebar"></div>

    <!-- Main -->
    <div class="main">
      <header class="header card">
        <div class="header-left">
          <button v-if="isMobile" class="btn btn-ghost btn-md" @click="openSidebar" aria-label="menu">☰</button>
          <div style="min-width:0">
            <div class="header-title">{{ headerTitle }}</div>
            <div class="header-sub">{{ headerSub }}</div>
          </div>
        </div>
        <div class="header-right">
          <span class="label">Theme</span>
          <button class="btn btn-sm" :class="{ 'btn-primary': theme==='light' }" @click="setTheme('light')">Light</button>
          <button class="btn btn-sm" :class="{ 'btn-primary': theme==='dim' }" @click="setTheme('dim')">Dim</button>
          <button class="btn btn-sm" :class="{ 'btn-primary': theme==='dark' }" @click="setTheme('dark')">Dark</button>
        </div>
      </header>

      <main class="content">
        <!-- CHAT -->
        <div v-if="view==='chat'" class="chat-shell">
          <section class="messages" ref="messagesEl">
            <div v-for="m in currentMessages" :key="m.id" class="msg" :class="m.role">
              <div v-if="m.role==='assistant'" class="avatar" style="width:28px;height:28px;font-size:12px;">AI</div>

              <div class="bubble">
                <div>{{ m.text }}</div>
                <div class="mini">{{ formatTime(m.ts) }}</div>
              </div>

              <div v-if="m.role==='user'" class="avatar" style="width:28px;height:28px;font-size:12px;">ME</div>
            </div>
            <div style="height: 24px"></div>
          </section>

          <section class="composer">
            <input class="input"
                   v-model="text"
                   placeholder="메시지를 입력하세요..."
                   @keydown.enter.exact.prevent="send"
            />
            <button class="btn btn-primary btn-md" @click="send">Send</button>
          </section>
        </div>

        <!-- PLAYGROUND -->
        <div v-else class="card" style="margin: 0 var(--s-3); padding: var(--s-4);">
          <div style="font-weight:800; margin-bottom: 10px;">Playground</div>
          <div style="color: var(--muted); line-height: 1.6;">
            여기에는 나중에 Data / Navigators 같은 탭을 붙일 수 있어요.<br/>
            지금은 라우팅(상태 전환) 분리만 구현된 상태입니다.
          </div>
          <div style="margin-top: 14px; display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-sm">btn-sm</button>
            <button class="btn btn-md">btn-md</button>
            <button class="btn btn-lg btn-primary">btn-lg primary</button>
            <span class="label">label</span>
          </div>
        </div>
      </main>

      <footer style="padding: 10px; text-align:center; color: var(--muted); font-size: var(--font-sm);">
        chat app
      </footer>
    </div>
  </div>
</template>

<script>
let idSeq = 1;
const nowTs = () => Date.now();

export default {
  name: "App",
  data() {
    return {
      view: "chat",
      isMobile: false,
      sidebarOpen: false,

      theme: document.documentElement.dataset.theme || "dim",

      chats: [
        {
          id: 1,
          title: "Temp Chat 1",
          messages: [
            { id: idSeq++, role: "assistant", text: "안녕하세요! ChatGPT 스타일 UI 템플릿입니다.", ts: nowTs() - 1000 * 60 * 2 },
            { id: idSeq++, role: "user", text: "sm에서 햄버거 + 슬라이드, 자동 스크롤, 말풍선 분리 해줘", ts: nowTs() - 1000 * 60 },
            { id: idSeq++, role: "assistant", text: "완료! 메시지 입력하면 자동으로 아래로 스크롤됩니다.", ts: nowTs() - 1000 * 50 },
          ],
        },
        {
          id: 2,
          title: "Temp Chat 2",
          messages: [
            { id: idSeq++, role: "assistant", text: "두번째 채팅방입니다.", ts: nowTs() - 1000 * 90 },
          ],
        },
      ],
      activeChatId: 1,
      text: "",
      resizeHandler: null,
    };
  },
  computed: {
    currentChat() {
      return this.chats.find((c) => c.id === this.activeChatId);
    },
    currentMessages() {
      return this.currentChat ? this.currentChat.messages : [];
    },
    headerTitle() {
      return this.view === "chat" ? "Chat" : "Playground";
    },
    headerSub() {
      if (this.view !== "chat") return "components / utilities 테스트 영역";
      return this.currentChat ? this.currentChat.title : "채팅방";
    },
  },
  watch: {
    // (2) auto scroll when messages change
    currentMessages: {
      deep: true,
      handler() {
        this.$nextTick(() => this.scrollToBottom());
      },
    },
    isMobile(v) {
      if (!v) this.sidebarOpen = false;
    },
  },
  mounted() {
    this.resizeHandler = () => {
      this.isMobile = window.innerWidth <= 768;
    };
    this.resizeHandler();
    window.addEventListener("resize", this.resizeHandler, { passive: true });

    // initial scroll
    this.$nextTick(() => this.scrollToBottom());
  },
  beforeUnmount() {
    window.removeEventListener("resize", this.resizeHandler);
  },
  methods: {
    // (1) sidebar mobile
    openSidebar() { this.sidebarOpen = true; },
    closeSidebar() { this.sidebarOpen = false; },

    go(view) {
      this.view = view;
      if (this.isMobile) this.closeSidebar();
    },

    selectChat(id) {
      this.activeChatId = id;
      if (this.isMobile) this.closeSidebar();
      this.$nextTick(() => this.scrollToBottom());
    },

    newRoom() {
      const nextId = Math.max(...this.chats.map(c => c.id)) + 1;
      this.chats.unshift({
        id: nextId,
        title: "Temp Chat " + nextId,
        messages: [{ id: idSeq++, role: "assistant", text: "새 채팅방이 생성되었습니다.", ts: nowTs() }],
      });
      this.activeChatId = nextId;
      if (this.isMobile) this.closeSidebar();
      this.$nextTick(() => this.scrollToBottom());
    },

    // (3) bubbles roles + sending
    send() {
      const t = (this.text || "").trim();
      if (!t) return;

      this.currentMessages.push({ id: idSeq++, role: "user", text: t, ts: nowTs() });
      this.text = "";

      // demo assistant reply
      const reply = "Echo: " + t;
      setTimeout(() => {
        this.currentMessages.push({ id: idSeq++, role: "assistant", text: reply, ts: nowTs() });
      }, 250);
    },

    scrollToBottom() {
      const el = this.$refs.messagesEl;
      if (!el) return;
      el.scrollTop = el.scrollHeight;
    },

    setTheme(t) {
      this.theme = t;
      document.documentElement.dataset.theme = t;
      try { localStorage.setItem("theme", t); } catch (e) {}
    },

    formatTime(ts) {
      const d = new Date(ts);
      const hh = String(d.getHours()).padStart(2, "0");
      const mm = String(d.getMinutes()).padStart(2, "0");
      return hh + ":" + mm;
    },
  },
  created() {
    try {
      const saved = localStorage.getItem("theme");
      if (saved) {
        this.theme = saved;
        document.documentElement.dataset.theme = saved;
      }
    } catch (e) {}
  },
};
</script>
