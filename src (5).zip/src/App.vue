<template>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <h3>DS Assistant</h3>
      <div class="nav gap-1">
        <button class="active">Chat</button>
        <button>Playground</button>
      </div>

      <hr class="m-2"/>

      <h4 class="label m-1">임시 채팅방</h4>
      <button class="btn btn-sm m-1">Temp Chat 1</button>
      <button class="btn btn-sm m-1">Temp Chat 2</button>

      <div style="margin-top:auto" class="label">MW 민우 송</div>
    </aside>

    <!-- Main -->
    <div class="main">
      <header class="header">
        <strong>Chat</strong>
        <div class="gap-1">
          <span class="label">Theme</span>
          <button class="btn btn-sm" @click="setTheme('light')">Light</button>
          <button class="btn btn-sm" @click="setTheme('dim')">Dim</button>
          <button class="btn btn-sm" @click="setTheme('dark')">Dark</button>
        </div>
      </header>

      <main class="content">
        <div class="chat-wrap">
          <div class="messages">
            <div class="msg"><div class="bubble">안녕하세요! ChatGPT 스타일 UI 템플릿입니다.</div></div>
            <div class="msg user"><div class="bubble">Bootstrap 급 유틸리티 적용해주세요.</div></div>
          </div>

          <div class="composer">
            <input class="input input-md" placeholder="메시지를 입력하세요"/>
            <button class="btn btn-primary btn-md">Send</button>
          </div>
        </div>
      </main>

      <footer class="footer">chat app</footer>
    </div>
  </div>
</template>

<script>
export default {
  methods:{
    setTheme(t){document.documentElement.dataset.theme=t;}
  }
}
</script>
