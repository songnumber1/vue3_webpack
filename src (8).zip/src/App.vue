
<template>
<div class="layout">
  <aside class="sidebar"
    :class="[{collapsed: !isMobile && collapsed},{open: isMobile && mobileOpen}]">
    <strong class="text">DS Assistant</strong>
    <small class="label">ChatGPT layout</small>

    <div class="nav">
      <button :class="{active:view==='chat'}" @click="go('chat')">💬 <span class="text">Chat</span></button>
      <button :class="{active:view==='playground'}" @click="go('playground')">🧪 <span class="text">Playground</span></button>
    </div>

    <div class="label">임시 채팅방</div>
    <button v-for="c in chats" :key="c.id"
      :class="{active:c.id===activeChatId}"
      @click="selectChat(c.id)">
      📄 <span class="text">{{c.title}}</span>
    </button>

    <button style="margin-top:auto" @click="newChat">➕ <span class="text">새 대화</span></button>
  </aside>

  <div v-if="isMobile && mobileOpen" class="overlay" @click="mobileOpen=false"></div>

  <div class="main">
    <header class="header">
      <button @click="toggleSidebar">☰</button>
      <strong>{{view}}</strong>
      <div>
        <button class="theme-btn" :class="{active:theme==='light'}" @click="setTheme('light')">Light</button>
        <button class="theme-btn" :class="{active:theme==='dim'}" @click="setTheme('dim')">Dim</button>
        <button class="theme-btn" :class="{active:theme==='dark'}" @click="setTheme('dark')">Dark</button>
      </div>
    </header>

    <!-- CHAT -->
    <main class="content" v-if="view==='chat'">
      <div class="chat-box">
        <div class="messages">
          <div v-for="(m,i) in activeChat.messages" :key="i" class="msg" :class="m.role">
            <div class="bubble">{{m.text}}</div>
          </div>
        </div>
        <div class="input-row">
          <input v-model="input" placeholder="메시지를 입력하세요"/>
          <button @click="send">Send</button>
        </div>
      </div>
    </main>

    <!-- PLAYGROUND -->
    <main class="content" v-else>
      <div class="tabs">
        <button :class="{active:pgTab==='data'}" @click="pgTab='data'">Data</button>
        <button :class="{active:pgTab==='nav'}" @click="pgTab='nav'">Navigator</button>
        <button :class="{active:pgTab==='chart'}" @click="pgTab='chart'">Chart</button>
      </div>
      <div>
        <p v-if="pgTab==='data'">Data Playground</p>
        <p v-else-if="pgTab==='nav'">Navigator Playground</p>
        <p v-else>Chart Playground</p>
      </div>
    </main>
  </div>
</div>
</template>

<script>
export default{
 data(){
   return{
     view:'chat',
     chats:[],
     activeChatId:null,
     input:'',
     collapsed:false,
     mobileOpen:false,
     isMobile: window.innerWidth<=768,
     theme:'light',
     pgTab:'data'
   }
 },
 computed:{
   activeChat(){
     return this.chats.find(c=>c.id===this.activeChatId) || {messages:[]}
   }
 },
 mounted(){
   const savedTheme = localStorage.getItem('theme')
   if(savedTheme) this.setTheme(savedTheme)

   const savedChats = localStorage.getItem('chats')
   if(savedChats){
     this.chats = JSON.parse(savedChats)
     this.activeChatId = this.chats[0]?.id
   }else{
     this.newChat()
   }
   window.addEventListener('resize',this.onResize)
 },
 beforeUnmount(){
   window.removeEventListener('resize',this.onResize)
 },
 methods:{
   persist(){
     localStorage.setItem('chats',JSON.stringify(this.chats))
   },
   newChat(){
     const id = Date.now()
     this.chats.unshift({id,title:'New Chat',messages:[]})
     this.activeChatId=id
     this.persist()
   },
   selectChat(id){
     this.activeChatId=id
     if(this.isMobile) this.mobileOpen=false
   },
   send(){
     if(!this.input.trim()) return
     this.activeChat.messages.push({role:'user',text:this.input})
     this.input=''
     this.persist()
   },
   toggleSidebar(){
     if(this.isMobile) this.mobileOpen=!this.mobileOpen
     else this.collapsed=!this.collapsed
   },
   go(v){
     this.view=v
     if(this.isMobile) this.mobileOpen=false
   },
   setTheme(t){
     this.theme=t
     document.documentElement.setAttribute('data-theme',t)
     localStorage.setItem('theme',t)
   },
   onResize(){
     this.isMobile = window.innerWidth<=768
     if(this.isMobile) this.collapsed=false
   }
 }
}
</script>
