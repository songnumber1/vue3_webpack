<template>
  <div class="layout">
    <aside class="sidebar">Sidebar</aside>

    <div class="main">
      <header class="header">
        <strong>ChatGPT UI</strong>
        <div>
          <button class="btn btn-sm" @click="$theme.setTheme('light')">Light</button>
          <button class="btn btn-sm" @click="$theme.setTheme('dim')">Dim</button>
          <button class="btn btn-sm" @click="$theme.setTheme('dark')">Dark</button>
        </div>
      </header>

      <main class="content">
        <div class="chat">
          <div class="message">Hello 👋 ChatGPT style layout</div>
          <div class="message">Sidebar, theme, utilities are restored</div>
        </div>
      </main>

      <footer class="footer">chat app</footer>
    </div>
  </div>
</template>

<script>
export default { name: "App" };
</script>
