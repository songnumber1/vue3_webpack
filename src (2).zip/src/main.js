import { createApp } from "vue";
import App from "./App.vue";
import themeManager from "./plugins/themeManager";
import "./assets/main.scss";

createApp(App)
  .use(themeManager)
  .mount("#app");
