<template>
  <div class="chat">
    <section class="messages card">
      <div class="msg assistant">
        <div class="bubble">
          안녕하세요! 왼쪽 사이드바 / 상단 테마 토글 / 반응형(햄버거) / sm·md·lg 유틸리티가 적용된 기본 템플릿입니다.
        </div>
      </div>

      <div class="msg user">
        <div class="bubble">
          Webpack + Vue3 Option API로 ChatGPT 레이아웃 만들고 싶어요.
        </div>
      </div>

      <div class="spacer"></div>
    </section>

    <section class="composer card">
      <input class="input" v-model="text" placeholder="Send a message..." @keydown.enter="send" />
      <button class="btn btn-primary btn-rsp" @click="send">Send</button>
    </section>
  </div>
</template>

<script>
export default {
  name: "ChatView",
  data() {
    return { text: "" };
  },
  methods: {
    send() {
      // demo only
      this.text = "";
    },
  },
};
</script>

<style scoped lang="scss">
.chat {
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: var(--gap-2);
}

/* messages panel */
.messages {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: var(--gap-2);
}

.msg {
  display: flex;
  margin-bottom: var(--gap-2);
}
.msg.assistant { justify-content: flex-start; }
.msg.user { justify-content: flex-end; }

.bubble {
  max-width: min(760px, 92%);
  padding: calc(12px * var(--ui-scale)) calc(14px * var(--ui-scale));
  border-radius: 16px;
  border: 1px solid var(--line);
  background: color-mix(in oklab, var(--panel-2), var(--panel) 30%);
  line-height: 1.45;
}
.msg.user .bubble {
  background: color-mix(in oklab, var(--accent), var(--panel) 82%);
  border-color: color-mix(in oklab, var(--accent), var(--line) 40%);
}

.spacer { height: 40px; }

/* composer */
.composer {
  display: flex;
  gap: var(--gap-1);
  padding: var(--gap-2);
  align-items: center;
}
</style>
