<template>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <h3>Chats</h3>
      <ul>
        <li v-for="c in chats" :key="c.id">
          <a href="#" @click.prevent="activeChat = c.id">{{ c.title }}</a>
        </li>
      </ul>
      <hr />
      <button class="btn btn-sm" @click="view='chat'">Chat</button>
      <button class="btn btn-sm" @click="view='playground'">Playground</button>
    </aside>

    <!-- Main -->
    <div class="main">
      <header class="header">
        <strong>{{ viewTitle }}</strong>
        <div>
          <button class="btn btn-sm" @click="setTheme('light')">Light</button>
          <button class="btn btn-sm" @click="setTheme('dim')">Dim</button>
          <button class="btn btn-sm" @click="setTheme('dark')">Dark</button>
        </div>
      </header>

      <main class="content" v-if="view==='chat'">
        <div class="chat-list">
          <div v-for="(m,i) in currentMessages" :key="i" class="message">
            {{ m }}
          </div>
        </div>
      </main>

      <main class="content" v-else>
        <div class="message">Playground Area</div>
      </main>

      <div class="chat-input" v-if="view==='chat'">
        <input class="input" v-model="text" placeholder="Type message..." @keyup.enter="send" />
        <button class="btn btn-primary btn-md" @click="send">Send</button>
      </div>

      <footer class="footer">chat app</footer>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      view: "chat",
      chats: [
        { id: 1, title: "Temp Chat 1", messages: [] },
        { id: 2, title: "Temp Chat 2", messages: [] }
      ],
      activeChat: 1,
      text: ""
    };
  },
  computed: {
    currentMessages() {
      return this.chats.find(c => c.id === this.activeChat).messages;
    },
    viewTitle() {
      return this.view === "chat" ? "Chat" : "Playground";
    }
  },
  methods: {
    send() {
      if (!this.text) return;
      this.currentMessages.push(this.text);
      this.text = "";
    },
    setTheme(t) {
      document.documentElement.dataset.theme = t;
    }
  }
};
</script>
