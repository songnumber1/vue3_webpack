<template>
<div class="layout">
  <aside class="sidebar"
    :class="[
      {collapsed: !isMobile && collapsed},
      {open: isMobile && mobileOpen}
    ]">
    <strong class="text">DS Assistant</strong>
    <small class="label">ChatGPT layout</small>

    <div class="nav">
      <button :class="{active:view==='chat'}" @click="go('chat')">
        💬 <span class="text">Chat</span>
      </button>
      <button :class="{active:view==='playground'}" @click="go('playground')">
        🧪 <span class="text">Playground</span>
      </button>
    </div>

    <div class="label">임시 채팅방</div>
    <button @click="selectChat(1)">📄 <span class="text">Temp Chat 1</span></button>
    <button @click="selectChat(2)">📄 <span class="text">Temp Chat 2</span></button>

    <button style="margin-top:auto">➕ <span class="text">새 대화</span></button>
  </aside>

  <div v-if="isMobile && mobileOpen" class="overlay" @click="mobileOpen=false"></div>

  <div class="main">
    <header class="header">
      <button @click="toggleSidebar">☰</button>
      <strong>{{view}}</strong>
      <div>
        <button class="theme-btn"
          :class="{active:theme==='light'}"
          @click="setTheme('light')">Light</button>
        <button class="theme-btn"
          :class="{active:theme==='dim'}"
          @click="setTheme('dim')">Dim</button>
        <button class="theme-btn"
          :class="{active:theme==='dark'}"
          @click="setTheme('dark')">Dark</button>
      </div>
    </header>

    <main class="content">
      <h3>{{view}} {{activeChat}}</h3>
    </main>
  </div>
</div>
</template>

<script>
export default{
 data(){
   return{
     view:'chat',
     activeChat:1,
     collapsed:false,
     mobileOpen:false,
     isMobile: window.innerWidth<=768,
     theme:'light'
   }
 },
 mounted(){
   const saved = localStorage.getItem('theme')
   if(saved) this.setTheme(saved)
   window.addEventListener('resize',this.onResize)
 },
 beforeUnmount(){
   window.removeEventListener('resize',this.onResize)
 },
 methods:{
   onResize(){
     this.isMobile = window.innerWidth<=768
     if(this.isMobile) this.collapsed=false
   },
   toggleSidebar(){
     if(this.isMobile){
       this.mobileOpen = !this.mobileOpen
     }else{
       this.collapsed = !this.collapsed
     }
   },
   go(v){
     this.view=v
     if(this.isMobile) this.mobileOpen=false
   },
   selectChat(id){
     this.activeChat=id
     if(this.isMobile) this.mobileOpen=false
   },
   setTheme(t){
     this.theme=t
     document.documentElement.setAttribute('data-theme',t)
     localStorage.setItem('theme',t)
   }
 }
}
</script>
