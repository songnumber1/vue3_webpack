
<template>
<div class="layout">
  <aside class="sidebar" :class="{collapsed:collapsed}">
    <strong class="text">DS Assistant</strong>
    <div>
      <button @click="$router.push('/chat')">💬 <span class="text">Chat</span></button>
      <button @click="$router.push('/playground')">🧪 <span class="text">Playground</span></button>
    </div>
  </aside>

  <div class="main">
    <header class="header">
      <button @click="collapsed=!collapsed">☰</button>
      <strong>DS Assistant</strong>
      <div>
        <button @click="setTheme('light')">Light</button>
        <button @click="setTheme('dim')">Dim</button>
        <button @click="setTheme('dark')">Dark</button>
      </div>
    </header>
    <router-view/>
  </div>
</div>
</template>

<script>
export default{
 data(){return{collapsed:false}},
 mounted(){
   const t=localStorage.getItem('theme')
   if(t) document.documentElement.setAttribute('data-theme',t)
 },
 methods:{
   setTheme(t){
     document.documentElement.setAttribute('data-theme',t)
     localStorage.setItem('theme',t)
   }
 }
}
</script>
