
<template>
<div class="content">
  <div class="chat-box">
    <div class="messages" ref="messages">
      <div v-for="(m,i) in messages" :key="i" class="msg" :class="m.role">
        <div class="bubble">{{m.text}}</div>
      </div>
    </div>
    <div class="input-row">
      <textarea v-model="input" rows="2"
        @keydown.enter.exact.prevent="send"
        @keydown.enter.shift.stop
        placeholder="메시지를 입력하세요"></textarea>
      <button @click="send">Send</button>
    </div>
  </div>
</div>
</template>

<script>
export default{
 data(){
   return{
     messages:[],
     input:''
   }
 },
 methods:{
   send(){
     if(!this.input.trim()) return
     this.messages.push({role:'user',text:this.input})
     this.input=''
     this.scroll()
     // mock AI
     setTimeout(()=>{
       this.messages.push({role:'ai',text:'AI 응답 예시입니다.'})
       this.scroll()
     },600)
   },
   scroll(){
     this.$nextTick(()=>{
       const el=this.$refs.messages
       el.scrollTop=el.scrollHeight
     })
   }
 }
}
</script>
