
<template>
<div class="content">
  <div class="tabs">
    <button :class="{active:tab==='data'}" @click="tab='data'">Data</button>
    <button :class="{active:tab==='nav'}" @click="tab='nav'">Navigator</button>
    <button :class="{active:tab==='chart'}" @click="tab='chart'">Chart</button>
  </div>
  <div>
    <p v-if="tab==='data'">Data playground</p>
    <p v-else-if="tab==='nav'">Navigator playground</p>
    <p v-else>Chart playground</p>
  </div>
</div>
</template>

<script>
export default{data(){return{tab:'data'}}}
</script>
