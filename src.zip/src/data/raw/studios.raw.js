import {DEFAULT_ASSISTANT_IMAGE} from "@/constants/assistantImages";

const defaultImage = DEFAULT_ASSISTANT_IMAGE.Image48Src;

export const STUDIOS_RAW = [
  {
    Image48Src: defaultImage,
    studioCatCode: ["MKT"],
    fixYN: false,
    image20Src: defaultImage,
    delYN: false,
    authYN: true,
    likeCnt: 12,
    shardStudioYN: false,
    assistName: "마케팅 스튜디오",
    image16Src: defaultImage,
    studioYN: true,
    regUserId: "user-1234",
    fileYN: false,
    assistId: "studio-marketing",
  },
  {
    Image48Src: defaultImage,
    studioCatCode: ["DEV", "OPS"],
    fixYN: false,
    image20Src: defaultImage,
    delYN: false,
    authYN: true,
    likeCnt: 8,
    shardStudioYN: true,
    assistName: "운영 장애 분석 스튜디오",
    image16Src: defaultImage,
    studioYN: true,
    regUserId: "user-1234",
    fileYN: true,
    assistId: "studio-ops",
  },
];
