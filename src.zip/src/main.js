import { createApp } from "vue";
import App from "./App.vue";
import responsiveManager from "./plugins/responsiveManager";
import themeManager from "./plugins/themeManager";
import "./assets/main.scss";

createApp(App)
  .use(responsiveManager)
  .use(themeManager)
  .mount("#app");
