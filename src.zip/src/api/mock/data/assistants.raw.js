/**
 * @file api/mock/data/assistants.raw.js
 * @description 개발/데모용 mock API 또는 mock 데이터입니다. 실제 API 비활성화 시 화면 동작을 보장합니다.
 *
 * 프리징 코드 주석 기준:
 * - 이 주석은 코드 추적을 돕기 위한 설명이며 런타임 동작을 변경하지 않습니다.
 * - 함수/상태가 다른 composable, store, component로 전달되는 경우 호출 방향을 먼저 확인하세요.
 */

import {DEFAULT_ASSISTANT_IMAGE} from "@/constants/assistantImages";

export const ASSISTANTS_RAW = [
  {
    delYN: false,
    authYN: true,
    isRagIndexesApi: false,
    fixYN: true,
    privateYN: false,
    sharedStudioYN: false,
    assistName: "DS Assistant",
    studioYN: false,
    assistOrder: 0,
    ragYN: true,
    assistId: "assist-ds",
    ...DEFAULT_ASSISTANT_IMAGE,
  },
  {
    delYN: false,
    authYN: true,
    isRagIndexesApi: false,
    fixYN: false,
    privateYN: false,
    sharedStudioYN: false,
    assistName: "Code Review Assistant",
    studioYN: false,
    assistOrder: 1,
    ragYN: false,
    assistId: "assist-code",
    ...DEFAULT_ASSISTANT_IMAGE,
  },
  {
    delYN: false,
    authYN: true,
    isRagIndexesApi: true,
    fixYN: false,
    privateYN: false,
    sharedStudioYN: false,
    assistName: "Architecture Assistant",
    studioYN: false,
    assistOrder: 2,
    ragYN: true,
    assistId: "assist-arch",
    ...DEFAULT_ASSISTANT_IMAGE,
  },
  {
    delYN: false,
    authYN: true,
    isRagIndexesApi: false,
    fixYN: false,
    privateYN: true,
    sharedStudioYN: false,
    assistName: "Writing Assistant",
    studioYN: false,
    assistOrder: 3,
    ragYN: false,
    assistId: "assist-writing",
    ...DEFAULT_ASSISTANT_IMAGE,
  },
  {
    delYN: false,
    authYN: true,
    isRagIndexesApi: false,
    fixYN: false,
    privateYN: false,
    sharedStudioYN: false,
    assistName: "Data Analysis Assistant",
    studioYN: false,
    assistOrder: 4,
    ragYN: true,
    assistId: "assist-data",
    ...DEFAULT_ASSISTANT_IMAGE,
  },
];
