<template>
  <footer
    class="shared-readonly-wrap"
    :class="`shared-readonly-wrap--${variant}`"
    :aria-label="titleText"
  >
    <div class="shared-readonly-box" :class="`shared-readonly-box--${variant}`">
      <span class="shared-readonly-icon" aria-hidden="true">
        <svg v-if="variant === 'deleted-model'" viewBox="0 0 24 24">
          <path
            d="M12 3.5 21 20H3L12 3.5Z"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linejoin="round"
          />
          <path
            d="M12 9v4.4M12 16.8h.01"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
          />
        </svg>
        <svg v-else viewBox="0 0 24 24">
          <path
            d="M7 11.5V8a5 5 0 0 1 10 0v3.5M6.5 11.5h11A1.5 1.5 0 0 1 19 13v6a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19v-6a1.5 1.5 0 0 1 1.5-1.5Z"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </span>
      <span class="shared-readonly-text">
        <strong>{{ titleText }}</strong>
        <span>{{ descriptionText }}</span>
      </span>
    </div>
  </footer>
</template>

<script setup>
/**
 * @file components/chat/ChatReadonlyInput.vue
 * @description 채팅 UI 컴포넌트입니다. 메시지, 헤더, 입력 영역, 이미지 프리뷰 등 실제 화면 렌더를 담당합니다.
 *
 * 프리징 코드 주석 기준:
 * - 이 주석은 코드 추적을 돕기 위한 설명이며 런타임 동작을 변경하지 않습니다.
 * - 함수/상태가 다른 composable, store, component로 전달되는 경우 호출 방향을 먼저 확인하세요.
 */

import {computed} from "vue";
import {useI18n} from "vue-i18n";

/**
 * 상위 컴포넌트에서 전달되는 렌더링/상태 제어 입력값입니다.
 */
const props = defineProps({
  variant: {type: String, default: "shared"},
  title: {type: String, default: ""},
  description: {type: String, default: ""},
});

const {t} = useI18n();

const titleText = computed(() => {
  if (props.title) return props.title;
  if (props.variant === "deleted-model")
    return t("chat.readonlyInput.deletedModelTitle");
  if (props.variant === "unavailable-model")
    return t("chat.readonlyInput.unavailableModelTitle");
  return t("chat.sharedReadonly");
});

const descriptionText = computed(() => {
  if (props.description) return props.description;
  if (props.variant === "deleted-model")
    return t("chat.readonlyInput.deletedModelDesc");
  if (props.variant === "unavailable-model")
    return t("chat.readonlyInput.unavailableModelDesc");
  return t("chat.readonlyInput.sharedDesc");
});
</script>
