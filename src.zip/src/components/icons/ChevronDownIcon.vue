<template>
  <svg
    class="app-icon app-icon--chevron"
    viewBox="0 0 20 20"
    aria-hidden="true"
  >
    <path
      d="M5.5 7.5 10 12l4.5-4.5"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
