<template>
  <div class="layout">
    <div class="sidebar">Sidebar</div>
    <div class="main">
      <div class="header">
        <button @click="$theme.setTheme('light')">Light</button>
        <button @click="$theme.setTheme('dim')">Dim</button>
        <button @click="$theme.setTheme('dark')">Dark</button>
      </div>
      <div class="content">
        <div class="chat-box">Chat UI is now visible</div>
      </div>
      <div class="footer">footer</div>
    </div>
  </div>
</template>
<script>
export default { name: "App" };
</script>
