/**
 * @file i18n/domains/chat.js
 * @description 다국어 메시지와 locale 관리 모듈입니다.
 *
 * 프리징 코드 주석 기준:
 * - 이 주석은 코드 추적을 돕기 위한 설명이며 런타임 동작을 변경하지 않습니다.
 * - 함수/상태가 다른 composable, store, component로 전달되는 경우 호출 방향을 먼저 확인하세요.
 */

export const chatMessages = {
  ko: {
    chat: {
      assistantSelect: "Assistant 선택",
      assistantSelected: "현재 선택된 어시스턴트",
      modelSelect: "모델 선택",
      modelReadonly: "대화방 모델은 변경할 수 없습니다.",
      tools: "도구",
      attachOptions: {
        camera: "카메라",
        image: "이미지",
        file: "파일",
      },
      hideSidebar: "사이드바 숨기기",
      collapsedSidebar: "접힌 사이드바",
      openSidebar: "사이드바 열기",
      newChat: "새 채팅",
      chatSearch: "채팅 검색",
      conversations: "대화",
      recentChats: "최근 채팅",
      startQuestion: "어디서부터 시작할까요?",
      sharedReadonly: "공유 받은 대화입니다.",
      readonlyInput: {
        deletedModelTitle: "삭제된 모델입니다.",
        deletedModelDesc:
          "이전 대화 내용은 확인할 수 있지만 새 메시지는 보낼 수 없습니다.",
        unavailableModelTitle: "사용할 수 없는 모델입니다.",
        unavailableModelDesc:
          "대화 이력은 열 수 있지만 모델 정보를 찾을 수 없어 새 메시지는 보낼 수 없습니다.",
        sharedDesc: "이 화면에서는 메시지를 입력하거나 전송할 수 없습니다.",
      },
      scrollBottom: "맨 아래로 이동",
      assistant: "Assistant",
      sharedConversationTitle: "공유 대화 {id}",
      promptPlaceholder: "무엇이든 물어보세요",
      send: "전송",
      voiceStart: "음성 입력 시작",
      voiceStop: "음성 입력 중지",
      attach: "첨부",
      templates: {
        mail: "메일",
        mailDescription: "메일 작성 템플릿",
        translate: "번역",
        translateDescription: "번역 템플릿",
        summary: "요약",
        summaryDescription: "요약 템플릿",
        code: "코드",
        codeDescription: "코드 생성/리뷰 템플릿",
      },
      suggestions: {
        image: "이미지 만들기",
        writing: "글쓰기 또는 편집",
        search: "필요한 항목 찾기",
        knowledgeSearch: "지식 검색",
        knowledge: {
          paper: "논문",
          confluence: "Confluence",
          jira: "Jira",
        },
        webSearch: "웹 검색",
        web: {
          perplexity: "퍼블렉시티",
          googleAiOverviews: "구글 AI 오버뷰",
          chatgptSearch: "오픈 AI 챗 GP",
          microsoftCopilot: "마이크로소프트 코파일럿",
        },
      },
      historyMenu: {
        title: "대화방 메뉴",
        pin: "즐겨찾기",
        unpin: "즐겨찾기 해지",
        rename: "제목 변경",
        share: "공유",
        delete: "삭제",
      },
      historyDialog: {
        deleteTitle: "대화방 삭제",
        renameTitle: "대화방 제목 변경",
        selectedConversation: "선택한 대화방",
        deleteMessage: "'{title}'을(를) 삭제하시겠습니까?",
        shareSelected: "공유 버튼을 선택했습니다.",
        titleField: "대화방 제목",
      },
      historySync: {
        loadFailed: "대화방 리스트를 가져오는데 실패했습니다.",
      },
      lifecycle: {
        mobileBackgroundAbortResumeAlert:
          "모바일 백그라운드 전환으로 진행 중인 답변 요청이 종료되었습니다.",
      },
      imagePreview: {
        loading: "이미지를 불러오는 중입니다...",
        error: "이미지를 미리보기로 표시할 수 없습니다.",
        close: "닫기",
        enlarge: "{name} 크게 보기",
      },
      attachment: {
        listLabel: "첨부 파일 목록",
        preview: "{name} 미리보기",
        remove: "{name} 제거",
      },
      reasoning: {
        thinking: "생각중입니다.",
        completed: "생각이 완료되었습니다.",
      },
    },
    prompt: {
      modelSelect: "모델 선택",
      attach: "첨부",
      modelReadonly: "대화방 모델은 변경할 수 없습니다.",
    },
  },
  en: {
    chat: {
      assistantSelect: "Select assistant",
      assistantSelected: "Currently selected assistant",
      modelSelect: "Select model",
      modelReadonly: "The model for this chat cannot be changed.",
      tools: "Tools",
      attachOptions: {
        camera: "Camera",
        image: "Image",
        file: "File",
      },
      hideSidebar: "Hide sidebar",
      collapsedSidebar: "Collapsed sidebar",
      openSidebar: "Open sidebar",
      newChat: "New chat",
      chatSearch: "Search chats",
      conversations: "Chats",
      recentChats: "Recent chats",
      startQuestion: "Where should we start?",
      sharedReadonly: "This is a shared conversation.",
      readonlyInput: {
        deletedModelTitle: "This model has been deleted.",
        deletedModelDesc:
          "You can view this conversation, but you cannot send new messages.",
        unavailableModelTitle: "This model is unavailable.",
        unavailableModelDesc:
          "You can view this conversation, but model metadata is missing so new messages are blocked.",
        sharedDesc: "You cannot send messages from this screen.",
      },
      scrollBottom: "Scroll to bottom",
      assistant: "Assistant",
      sharedConversationTitle: "Shared chat {id}",
      promptPlaceholder: "Ask anything",
      send: "Send",
      voiceStart: "Start voice input",
      voiceStop: "Stop voice input",
      attach: "Attach",
      templates: {
        mail: "Mail",
        mailDescription: "Email writing template",
        translate: "Translate",
        translateDescription: "Translation template",
        summary: "Summary",
        summaryDescription: "Summary template",
        code: "Code",
        codeDescription: "Code generation/review template",
      },
      suggestions: {
        image: "Create image",
        writing: "Write or edit",
        search: "Find what you need",
        knowledgeSearch: "Knowledge search",
        knowledge: {
          paper: "Papers",
          confluence: "Confluence",
          jira: "Jira",
        },
        webSearch: "Web search",
        web: {
          perplexity: "Perplexity",
          googleAiOverviews: "Google AI Overviews",
          chatgptSearch: "ChatGPT Search",
          microsoftCopilot: "Microsoft Copilot",
        },
      },
      historyMenu: {
        title: "Chat menu",
        pin: "Add to favorites",
        unpin: "Remove from favorites",
        rename: "Rename",
        share: "Share",
        delete: "Delete",
      },
      historyDialog: {
        deleteTitle: "Delete chat",
        renameTitle: "Rename chat",
        selectedConversation: "selected chat",
        deleteMessage: "Delete '{title}'?",
        shareSelected: "Share was selected.",
        titleField: "Conversation title",
      },
      historySync: {
        loadFailed: "Failed to load the chat list.",
      },
      lifecycle: {
        mobileBackgroundAbortResumeAlert:
          "The in-progress answer request was ended because the mobile browser moved to the background.",
      },
      imagePreview: {
        loading: "Loading image...",
        error: "Unable to display image preview.",
        close: "Close",
        enlarge: "Enlarge {name}",
      },
      attachment: {
        listLabel: "Attached files",
        preview: "Preview {name}",
        remove: "Remove {name}",
      },
      reasoning: {
        thinking: "Thinking...",
        completed: "Thought completed.",
      },
    },
    prompt: {
      modelSelect: "Select model",
      attach: "Attach",
      modelReadonly: "The model for this chat cannot be changed.",
    },
  },
};
