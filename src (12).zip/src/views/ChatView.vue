
<template>
  <div class="content">
    <div class="chat-box">
      <div class="messages" ref="messages">
        <div v-if="isDraft && messages.length===0" style="color:var(--muted); padding:8px;">
          새 대화를 시작하세요. 첫 메시지 전송 시 좌측 이력에 추가됩니다.
        </div>

        <div v-for="(m,i) in messages" :key="i" class="msg" :class="m.role">
          <div class="bubble" v-html="render(m.text)"></div>
        </div>
      </div>

      <div class="input-row">
        <textarea
          v-model="input"
          rows="2"
          placeholder="메시지를 입력하세요 (Markdown 지원)"
          @keydown.enter.exact.prevent="send"
          @keydown.enter.shift.stop
        ></textarea>
        <button @click="send">Send</button>
      </div>
    </div>
  </div>
</template>

<script>
import { createChatFromFirstMessage } from '../services/chatStore';
import { md } from '../utils/markdown';

export default{
  props:{ store:{ type:Object, required:true }},
  data(){ return { input:'' }},
  computed:{
    isDraft(){ return !!this.store.draft || !this.store.activeChatId },
    activeChat(){
      return (this.store.chats||[]).find(c=>c.id===this.store.activeChatId)||null;
    },
    messages(){ return this.activeChat ? this.activeChat.messages : [] }
  },
  methods:{
    render(text){ return md.render(text||'') },
    ensureChatCreated(firstText){
      if(this.store.activeChatId) return;
      const chat = createChatFromFirstMessage(firstText);
      this.store.chats.unshift(chat);
      this.store.activeChatId = chat.id;
      this.store.draft = false;
      this.$emit('store:update', this.store);
    },
    send(){
      const text = (this.input||'').trim();
      if(!text) return;
      this.ensureChatCreated(text);
      this.activeChat.messages.push({ role:'user', text });
      this.input='';
      this.$emit('store:update', this.store);
      this.scroll();
      setTimeout(()=>{
        this.activeChat.messages.push({
          role:'ai',
          text:'```js\nconsole.log("markdown code block");\n```\n\n**Markdown 응답 예시입니다.**'
        });
        this.$emit('store:update', this.store);
        this.scroll();
      },400);
    },
    scroll(){
      this.$nextTick(()=>{
        const el=this.$refs.messages;
        if(el) el.scrollTop=el.scrollHeight;
      });
    }
  },
  mounted(){ this.scroll() },
  updated(){ this.scroll() }
}
</script>
